<?php
define('QUICKPAY_NAME', 'QuickPay');
define('QUICKPAY_LOGO', 'view/image/extension/payment/quickpay.svg');
define('QUICKPAY_LINK', 'https://quickpay.net');

define('QUICKPAY_URL_API', 'api.quickpay.net');
define('QUICKPAY_URL_PAYMENT', 'payment.quickpay.net');
define('QUICKPAY_URL_MANAGER', 'https://manage.quickpay.net');
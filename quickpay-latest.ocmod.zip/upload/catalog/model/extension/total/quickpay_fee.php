<?php

/**
 * Class ModelExtensionTotalQuickPayFee
 */
class ModelExtensionTotalQuickPayFee extends Model {

	/**
	 * @param $total
	 */
	public function getTotal( $total ) {

	}
}
<?php

$_['text_title']  = 'ViaBill';
$_['payment_fee'] = 'Payment fee';
<?php

$_['text_title']  = 'Sofort';
$_['payment_fee'] = 'Payment fee';
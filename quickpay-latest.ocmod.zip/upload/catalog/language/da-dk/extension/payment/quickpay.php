<?php

$_['text_title']       = 'Betalingskort';
$_['text_credit_card'] = 'Betalingskort - detaljer';
$_['payment_fee']      = 'Betalingsgebyr';